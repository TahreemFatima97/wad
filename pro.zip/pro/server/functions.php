<?php

require "db_connection.php";

function getCats()
{
    global $con;
    $getCatQuery = "select * from categories";
    $getCatResult = mysqli_query($con, $getCatQuery);
    while($row = mysqli_fetch_assoc($getCatResult))
    {
        $id = $row['Cat_Id'];
        $item = $row['Items'];
        echo "<li><a class = 'nav-link' href = '#'>$item</a></li>";
    }
   // print_r($row);

}

function getBrands()
{
    global $con;
    $getBrandQuery = "select * from brands";
    $getBrandResult = mysqli_query($con, $getBrandQuery);
    while ($row = mysqli_fetch_assoc($getBrandResult))
    {
        $name = $row['B_Name'];
        $id = $row['Brand_Id'];

        echo "<li><a class = 'nav-link' href = '#'>$name</a></li>";
    }
}

function getContent()
{
    global $con;
    $getBrandQuery = "select * from products";
    $getBrandResult = mysqli_query($con,$getBrandQuery);
    while ($row = mysqli_fetch_assoc($getBrandResult))
    {
        $Pro_Title = $row['Pro_Title'];
        $Pro_Cat = $row['Pro_Cat'];
        $Pro_Brand = $row['Pro_Brand'];
        $Pro_Price = $row['Pro_Price'];
        $Pro_Desc = $row['Pro_Desc'];
        $Pro_Keywords = $row['Pro_keywords'];
        echo "<li><b><i> PRODUCT DETAILS </i></b></li><br>";
        echo "<b>Product Title: </b>$Pro_Title<br>";
        echo "<b>Product Category: </b>$Pro_Cat<br>";
        echo "<b>Product Brand: </b>$Pro_Brand <br>";
        echo "<b>Product Price: </b>$Pro_Price<br>";
        echo "<b>Product Desc: </b>$Pro_Desc<br>";
        echo "<b>Product Keyword: </b>$Pro_Keywords<br>";
        echo "<br>";
    }
}