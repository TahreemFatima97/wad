<?php
$con = mysqli_connect("localhost","root","","tech_box");
if(!$con)
    die("Connection failed");