<?php
require "db_connection.php";
if(isset($_POST['insert_pro']))
{
    $Pro_Title =   $_POST['pro_title'];
    $Pro_Cat =  $_POST['pro_cat'];
    $Pro_Brand =  $_POST['pro_brand'];
    $Pro_Price =  $_POST['pro_price'];
    $Pro_Desc =  $_POST['pro_desc'];
    $Pro_Keywords =  $_POST['pro_kw'];

    $insertQuery = "insert into products(Pro_Title, Pro_Cat, Pro_Brand, Pro_Price, Pro_Desc, Pro_Keywords) 
values ('$Pro_Title', '$Pro_Cat', '$Pro_Brand', '$Pro_Price', '$Pro_Desc', '$Pro_Keywords');";
    $result = mysqli_query($con, $insertQuery);
    if(!$result)
    {
        echo "Not Executed";
    }
}

function getCats()
{
    global $con;
    $getCatQuery = "select * from categories";
    $getCatResult = mysqli_query($con, $getCatQuery);
    while($row = mysqli_fetch_assoc($getCatResult))
    {
        $id = $row['Cat_Id'];
        $item = $row['Items'];
        echo "<option>$item</option>";
    }
    // print_r($row);

}

function getBrands()
{
    global $con;
    $getBrandQuery = "select * from brands";
    $getBrandResult = mysqli_query($con, $getBrandQuery);
    while ($row = mysqli_fetch_assoc($getBrandResult))
    {
        $name = $row['B_Name'];
        $id = $row['Brand_Id'];

        echo "<option>$name</option>";
    }
}