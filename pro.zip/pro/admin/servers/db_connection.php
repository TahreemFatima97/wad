<?php
$con = mysqli_connect("localhost", "root", "", "techbox");
if(!$con)
{
    die("connection Failed");
}