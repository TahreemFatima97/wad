<?php

require "db_connection.php";

function getCats()
{
    global $con;
    $getCatQuery = "select * from categories";
    $getCatResult = mysqli_query($con, $getCatQuery);
    while($row = mysqli_fetch_assoc($getCatResult))
    {
        $id = $row['Cat_Id'];
        $item = $row['Items'];
        echo "<li><a class = 'nav-link' href = '#'>$item</a></li>";
    }
   // print_r($row);

}

function getBrands()
{
    global $con;
    $getBrandQuery = "select * from brands";
    $getBrandResult = mysqli_query($con, $getBrandQuery);
    while ($row = mysqli_fetch_assoc($getBrandResult))
    {
        $name = $row['B_Name'];
        $id = $row['Brand_Id'];

        echo "<li><a class = 'nav-link' href = '#'>$name</a></li>";
    }
}