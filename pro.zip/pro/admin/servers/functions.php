<?php

require "db_connection.php";

function getCats()
{
    global $con;
    $getCatQuery = "select * from categories";
    $getCatResult = mysqli_query($con, $getCatQuery);
    while($row = mysqli_fetch_assoc($getCatResult))
    {
        $id = $row['Cat_Id'];
        $item = $row['Items'];
        echo "<option>$item</option>";
    }
    // print_r($row);

}

function getBrands()
{
    global $con;
    $getBrandQuery = "select * from brands";
    $getBrandResult = mysqli_query($con, $getBrandQuery);
    while ($row = mysqli_fetch_assoc($getBrandResult))
    {
        $name = $row['B_Name'];
        $id = $row['Brand_Id'];

        echo "<option>$name</option>";
    }
}